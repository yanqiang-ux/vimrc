#include "main.h"

long my_global_long;
int  my_global_int;
T_TestStruct1 my_test_struct;

int main()
{
   /* do something */

   my_func_1();
   my_func_2();
}


