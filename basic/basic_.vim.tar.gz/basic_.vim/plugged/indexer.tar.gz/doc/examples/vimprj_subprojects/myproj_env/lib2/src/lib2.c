
void my_lib2(void)
{
}

