
void my_lib1(void)
{
}

