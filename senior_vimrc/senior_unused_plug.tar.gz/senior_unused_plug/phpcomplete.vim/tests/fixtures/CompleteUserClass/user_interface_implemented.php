<?php

class Foo implements FooAble {

}
interface FooAble {
	public function bar($baz = 42);
}

