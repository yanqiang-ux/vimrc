<?php
namespace NS1\SubNS2;

use NS2\SubNS\Level2;

class Level1 extends Level2 {

	protected function level1Method() {
		//
	}

	public function doSometing() {
		$this->
		$this->getLevel31Instance()->
		$this->getAnother31Instance()->
	}

}
