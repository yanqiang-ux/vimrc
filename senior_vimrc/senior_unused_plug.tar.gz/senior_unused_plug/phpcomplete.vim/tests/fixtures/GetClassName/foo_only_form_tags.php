<?php

$foo_only_in_tags->
$namespaced_foo_only_in_tags->
// TODO
$foo_only_in_tags::
