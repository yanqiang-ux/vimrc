<?php

class X implements Foo {
}

class Y implements Foo, Foo2 {
}

