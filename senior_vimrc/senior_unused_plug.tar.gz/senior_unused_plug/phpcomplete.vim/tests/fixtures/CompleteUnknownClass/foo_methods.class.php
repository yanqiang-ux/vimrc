<?php


class FooMethodsClass {
    function method1($foo) {
    }

    public function method2($foo) {
    }

    public static function method3($foo) {
    }

    static public function method4($foo) {
    }

    private function method5($foo) {
    }

    protected function method6($foo) {
    }
}
