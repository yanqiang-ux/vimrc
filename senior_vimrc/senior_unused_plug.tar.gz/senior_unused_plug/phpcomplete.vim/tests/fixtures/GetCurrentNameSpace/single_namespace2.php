<?php namespace Mahou;

class Foo {

}

$some = method_calls();
