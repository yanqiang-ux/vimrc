<?php
namespace NS1;
class Foo {
}
const ZAP = '';
function bar(){}



namespace NS1\SUBNS;
class FooSub {
}
function barsub(){}
const ZAPSUB = '';



namespace NS1\SUBNS\SUBSUB;
class FooSubSub {
}
function barsubsub(){}
const ZAPSUBSUB = '';
