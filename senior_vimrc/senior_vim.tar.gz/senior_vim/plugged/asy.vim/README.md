# asy.vim

Some vim files for asymptote files.
