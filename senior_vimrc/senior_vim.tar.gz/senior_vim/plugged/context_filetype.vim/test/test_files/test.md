

`markdown`


```cpp

`cpp`


```


```hoge

`hoge`

```


```vim

`vim`

python << EOF

`python`

vim.eval("`vim`")

EOF `vim`


ruby << EOF

`ruby`

EOF

		
```

```vim

ruby << EOF

`ruby`

EOF

```

```javascript

<script type="text/javascript">`javascript`

`javascript`

`javascript`

	 
`javascript`</script>


```

```cpp

`cpp`

    ```

```text
`text`本日は晴天なり`text`
```

`markdown`

