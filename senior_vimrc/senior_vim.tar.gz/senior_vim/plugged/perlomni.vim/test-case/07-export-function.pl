
# should complete after qw(
use List::MoreUtils qw();

use List::AllUtils qw/max /;


# should have exported function
# complete to "all"
a

# a to all

min

# m to max
