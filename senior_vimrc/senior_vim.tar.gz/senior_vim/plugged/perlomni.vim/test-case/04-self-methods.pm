package Test;


# complete current object methods
sub testtest {
    # complete after $self
    my $self

    # should complete to
    my $self = shift;


}

sub foo1 {
    my $self = shift;

    # should have foo1, foo2 ...
    $self->

}

sub foo2 { }

1;
